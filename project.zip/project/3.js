const pageStorage = {
    data: {},

    getItem(key) {
        return this.data[key] ?? null;
    },

    setItem(key, value) {
        this.data[key] = String(value);
    },

    removeItem(key) {
        delete this.data[key];
    }
};

const slides = document.getElementById("slides");
let index = 0;

function showSlide(number) {
    if (!slides || !slides.children.length) return;

    const count = slides.children.length;
    index = (number % count + count) % count;
    slides.style.transform = `translateX(-${index * 100}%)`;

    document.querySelectorAll(".dots button").forEach(function (button, i) {
        button.classList.toggle("active", i === index);
    });
}

function changeSlide(step) {
    showSlide(index + step);
}

function rate(value) {
    document.querySelectorAll(".rating button").forEach(function (star, i) {
        star.classList.toggle("active", i < value);
    });

    const text = document.getElementById("rating-text");

    if (text) {
        text.textContent = "Ваша оценка: " + value + " из 5";
    }
}

function toggleLike(button) {
    const liked = button.classList.toggle("liked");
    button.textContent = liked ? "♥" : "♡";
    button.setAttribute("aria-pressed", liked);
}

const tasks = [
    {
        id: 1,
        title: "Сайт для кофейни",
        employer: "Анна Смирнова",
        image: "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=1200",
        description: "Нужно создать одностраничный сайт для небольшой кофейни. Посетитель должен быстро найти меню, время работы и адрес.",
        requirements: "Добавить название и описание кофейни, меню с ценами, контакты и время работы. Страница должна удобно отображаться на компьютере и телефоне."
    },
    {
        id: 2,
        title: "Каталог товаров",
        employer: "Иван Петров",
        image: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1200",
        description: "Нужно разработать небольшой каталог одежды с названиями, фотографиями и ценами товаров.",
        requirements: "Создать минимум шесть карточек товаров, добавить поиск по названию, цену и описание каждого товара. Адаптировать каталог под мобильные устройства."
    },
    {
        id: 3,
        title: "Портфолио фотографа",
        employer: "Мария Волкова",
        image: "https://images.unsplash.com/photo-1452587925148-ce544e77e70d?w=1200",
        description: "Нужен сайт для представления работ фотографа. Главный акцент — на фотографиях, услугах и способах связи.",
        requirements: "Добавить галерею фотографий, информацию о фотографе, описание услуг и контакты. Сделать адаптивную вёрстку."
    }
];

function readTaskIds(key) {
    const saved = JSON.parse(pageStorage.getItem(key) || "[]");
    return Array.isArray(saved) ? saved : [];
}

function getJoinedTasks() {
    return readTaskIds("joinedTasks");
}

function getArchivedTasks() {
    return readTaskIds("archivedTasks");
}

function saveTaskLists(joined, archived) {
    pageStorage.setItem("joinedTasks", JSON.stringify(joined));
    pageStorage.setItem("archivedTasks", JSON.stringify(archived));
}

let noticeTimer;

function showNotice(text) {
    let notice = document.getElementById("notice");

    if (!notice) {
        notice = document.createElement("div");
        notice.id = "notice";
        notice.className = "notice";
        notice.setAttribute("role", "status");
        document.body.appendChild(notice);
    }

    notice.textContent = text;
    notice.hidden = false;

    clearTimeout(noticeTimer);

    noticeTimer = setTimeout(function () {
        notice.hidden = true;
    }, 3500);
}

const modal = document.createElement("dialog");
modal.className = "unsubscribe-modal";

modal.innerHTML = `
    <p>Точно ли вы хотите отписаться от данной работы?</p>
    <div class="modal-buttons">
        <button type="button" id="confirm-unsubscribe">Да</button>
        <button type="button" id="cancel-unsubscribe">Нет</button>
    </div>
`;

document.body.appendChild(modal);

let unsubscribeId = null;

function askUnsubscribe(id) {
    unsubscribeId = id;
    modal.showModal();
}

document.getElementById("cancel-unsubscribe").onclick = function () {
    modal.close();
};

modal.addEventListener("close", function () {
    unsubscribeId = null;
});

document.getElementById("confirm-unsubscribe").onclick = function () {
    if (unsubscribeId === null) return;

    const joined = getJoinedTasks().filter(function (id) {
        return id !== unsubscribeId;
    });

    const archived = getArchivedTasks();

    if (!archived.includes(unsubscribeId)) {
        archived.push(unsubscribeId);
    }

    saveTaskLists(joined, archived);
    modal.close();
    refreshTasks();

    showNotice("Вы успешно отписались. Задание перенесено в архив");
};

let currentTask = null;
const taskPage = document.getElementById("task-page");

function updateJoinButton() {
    if (!currentTask) return;

    const joined = getJoinedTasks().includes(currentTask.id);
    const button = document.getElementById("join-button");
    const message = document.getElementById("join-message");

    if (button) {
        button.disabled = false;
        button.textContent = joined ? "Отписаться" : "Участвовать";
    }

    if (message) {
        message.textContent = joined
            ? "Вы участвуете в выполнении задания."
            : "";
    }
}

if (taskPage) {
    const id = Number(new URLSearchParams(location.search).get("id"));

    currentTask = tasks.find(function (task) {
        return task.id === id;
    });

    if (!currentTask) {
        taskPage.textContent = "Задание не найдено.";
    } else {
        document.title = currentTask.title;

        document.getElementById("task-title").textContent =
            currentTask.title;

        document.getElementById("task-employer").textContent =
            "Работодатель: " + currentTask.employer;

        document.getElementById("task-image").src =
            currentTask.image;

        document.getElementById("task-description").textContent =
            currentTask.description;

        document.getElementById("task-requirements").textContent =
            currentTask.requirements;

        document.getElementById("join-button").onclick = function () {
            const joined = getJoinedTasks();

            if (joined.includes(currentTask.id)) {
                askUnsubscribe(currentTask.id);
                return;
            }

            joined.push(currentTask.id);

            const archived = getArchivedTasks().filter(function (id) {
                return id !== currentTask.id;
            });

            saveTaskLists(joined, archived);
            refreshTasks();
        };
    }
}

function createActions() {
    const actions = document.createElement("div");
    actions.style.display = "flex";
    actions.style.flexWrap = "wrap";
    actions.style.gap = "10px";
    return actions;
}

function createButton(text, className, action) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = className;
    button.textContent = text;
    button.onclick = action;
    return button;
}

function createTaskCard(task, archived) {
    const card = document.createElement("article");
    card.className = "task";

    const tag = document.createElement("span");
    tag.className = "tag";
    tag.textContent = archived ? "В архиве" : "В процессе";

    const link = document.createElement("a");
    link.href = "task.html?id=" + task.id;

    const title = document.createElement("h3");
    title.textContent = task.title;
    link.appendChild(title);

    const employer = document.createElement("p");
    employer.className = "employer";
    employer.textContent = "Работодатель: " + task.employer;

    const actions = createActions();

    if (archived) {
        actions.appendChild(createButton(
            "Восстановить",
            "primary-button",
            function () {
                const joined = getJoinedTasks();

                if (!joined.includes(task.id)) {
                    joined.push(task.id);
                }

                const archive = getArchivedTasks().filter(function (id) {
                    return id !== task.id;
                });

                saveTaskLists(joined, archive);
                refreshTasks();
                showNotice("Задание возвращено в работы в процессе");
            }
        ));

        actions.appendChild(createButton(
            "Удалить",
            "primary-button",
            function () {
                const archive = getArchivedTasks().filter(function (id) {
                    return id !== task.id;
                });

                saveTaskLists(getJoinedTasks(), archive);
                refreshTasks();
                showNotice("Задание удалено из архива");
            }
        ));
    } else {
        actions.appendChild(createButton(
            "Отписаться",
            "primary-button",
            function () {
                askUnsubscribe(task.id);
            }
        ));
    }

    card.append(tag, link, employer, actions);
    return card;
}

function renderProgress() {
    const container = document.getElementById("in-progress");
    if (!container) return;

    container.replaceChildren();

    tasks.forEach(function (task) {
        if (getJoinedTasks().includes(task.id)) {
            container.appendChild(createTaskCard(task, false));
        }
    });

    const empty = document.getElementById("empty-progress");

    if (empty) {
        empty.hidden = container.children.length > 0;
    }
}

const readyWorks = document.querySelector(
    '.profile-group[data-status="done"] .works'
);

const archiveSection = document.querySelector(
    '.profile-group[data-status="archive"]'
);

const profileWorks = {
    archived: []
};

if (readyWorks) {
    readyWorks.querySelectorAll(".work").forEach(function (card, i) {
        const link = card.querySelector('a[href^="work"]');

        card.dataset.workId = link
            ? link.getAttribute("href")
            : "work-" + i;

        addArchiveButton(card);
    });

    const addButton = document.getElementById("add-work");

    if (addButton) {
        addButton.onclick = function () {
            createEmptyWork();

            selectedFilter = "done";
            refreshTasks();
        };
    }
}

function createEmptyWork() {
    const card = document.createElement("article");
    card.className = "work";

    card.dataset.workId = "empty-" + Date.now() + "-" +
        Math.random().toString(36).slice(2, 7);

    const image = document.createElement("div");
    image.className = "empty-work-image";
    image.setAttribute("role", "img");
    image.setAttribute("aria-label", "Серая картинка");

    const title = document.createElement("h3");
    title.textContent = "Пустая работа";

    card.append(image, title);
    readyWorks.appendChild(card);
    addArchiveButton(card);
}

function addArchiveButton(card) {
    if (card.querySelector(".archive-work")) return;

    card.appendChild(createButton(
        "В архив",
        "archive-work",
        function () {
            const id = card.dataset.workId;

            if (!profileWorks.archived.includes(id)) {
                profileWorks.archived.push(id);
            }

            refreshTasks();
            showNotice("Работа добавлена в архив");
        }
    ));
}

if (archiveSection) {
    if (!document.getElementById("archived-tasks")) {
        const container = document.createElement("div");
        container.className = "tasks";
        container.id = "archived-tasks";
        archiveSection.appendChild(container);
    }

    if (!document.getElementById("completed-archive")) {
        const container = document.createElement("div");
        container.className = "works";
        container.id = "completed-archive";
        archiveSection.appendChild(container);
    }
}

function renderCompletedArchive() {
    const container = document.getElementById("completed-archive");
    if (!container || !readyWorks) return;

    container.replaceChildren();

    readyWorks.querySelectorAll(".work").forEach(function (card) {
        const id = card.dataset.workId;
        const archived = profileWorks.archived.includes(id);

        card.hidden = archived;
        if (!archived) return;

        const copy = card.cloneNode(true);
        copy.hidden = false;

        copy.querySelectorAll(".archive-work").forEach(function (button) {
            button.remove();
        });

        const actions = createActions();

        actions.appendChild(createButton(
            "Восстановить",
            "archive-work",
            function () {
                profileWorks.archived = profileWorks.archived.filter(
                    function (item) {
                        return item !== id;
                    }
                );

                refreshTasks();
                showNotice("Работа возвращена в готовые");
            }
        ));

        actions.appendChild(createButton(
            "Удалить",
            "archive-work",
            function () {
                profileWorks.archived = profileWorks.archived.filter(
                    function (item) {
                        return item !== id;
                    }
                );

                card.remove();

                refreshTasks();
                showNotice("Работа удалена");
            }
        ));

        copy.appendChild(actions);
        container.appendChild(copy);
    });
}

function renderArchive() {
    const container = document.getElementById("archived-tasks");

    if (container) {
        container.replaceChildren();

        const archived = getArchivedTasks();
        const joined = getJoinedTasks();

        tasks.forEach(function (task) {
            if (archived.includes(task.id) && !joined.includes(task.id)) {
                container.appendChild(createTaskCard(task, true));
            }
        });
    }

    renderCompletedArchive();

    if (archiveSection) {
        const empty = archiveSection.querySelector("#empty-archive")
            || archiveSection.querySelector(":scope > p");

        if (empty) {
            empty.hidden =
                archiveSection.querySelectorAll(".work, .task").length > 0;
        }
    }
}

const profileTabs = document.querySelector(".profile-tabs");
let selectedFilter = "all";

function updateProfileTabs() {
    if (!profileTabs) return;

    const counts = {
        done: 0,
        progress: 0,
        archive: 0
    };

    document.querySelectorAll(".profile-group").forEach(function (group) {
        const status = group.dataset.status;

        counts[status] = Array.from(
            group.querySelectorAll(".work, .task")
        ).filter(function (card) {
            return !card.hidden;
        }).length;

        group.hidden = selectedFilter === "all"
            ? status === "archive"
            : status !== selectedFilter;
    });

    counts.all = counts.done + counts.progress;

    profileTabs.querySelectorAll("button").forEach(function (button) {
        const active = button.dataset.filter === selectedFilter;

        button.classList.toggle("active", active);
        button.setAttribute("aria-pressed", active);

        const counter = button.querySelector("span");

        if (counter) {
            counter.textContent = counts[button.dataset.filter];
        }
    });
}

if (profileTabs) {
    profileTabs.querySelectorAll("button").forEach(function (button) {
        button.onclick = function () {
            selectedFilter = button.dataset.filter;
            updateProfileTabs();
        };
    });
}

function refreshTasks() {
    updateJoinButton();
    renderProgress();
    renderArchive();
    updateProfileTabs();
}

refreshTasks();